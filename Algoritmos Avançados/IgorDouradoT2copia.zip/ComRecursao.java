class ComRecursao{
    static int cont = 3;
    public static void main(String[] args) {
        String input= args[0];
        char[] vetorDeLetra= input.toCharArray();
        System.out.println(FazRecursao(vetorDeLetra, 0));
    }
    public static long FazRecursao(char[] entrada, int salto){
        if (entrada.length>salto){
            if (salto==entrada.length-1){
                return 1;
            }
            else if (entrada[salto]=='1'){
                if (entrada.length> salto+(cont*2) && entrada[salto+(cont*2)]=='1' && entrada[salto+cont]=='1' ){
                    return FazRecursao(entrada, salto +cont+2)+FazRecursao(entrada, salto +cont+1)+FazRecursao(entrada, salto +cont-1)+FazRecursao(entrada, salto +cont-2);
                }
                return FazRecursao(entrada, salto +cont)+FazRecursao(entrada, salto +cont-1)+FazRecursao(entrada, salto +cont-2);
            }
        }return 0;
    }
}