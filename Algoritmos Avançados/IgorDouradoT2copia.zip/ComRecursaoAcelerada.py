#Professor, não consegui achar uma biblioteca que fizesse a minha ideia de recursão
#em Java, então resolvi fazer em Python Baseado nas aulas do senhor e na minha
#recursão em Java

memoria = {}

def saltos(entrada, salto):
    if (len(entrada)>salto):
        if ((entrada[salto], salto) in memoria):
             return memoria[entrada[salto], salto]
        if (entrada[salto]== "1" and len(entrada)-1==salto):
            return 1
        elif (entrada[salto]== "1"):
            if len(entrada)>6+salto:
                if entrada[3+salto] == "1" and entrada[6+salto] == "1":
                    memoria[entrada[salto], salto] = saltos(entrada, 5+salto) + saltos(entrada, 4+salto) +saltos(entrada, 2+salto) + saltos(
                        entrada, 1+salto)
                    return memoria[entrada[salto], salto]
            memoria[entrada[salto], salto] = saltos(entrada, 3+salto) + saltos(entrada, 2+salto) + saltos(entrada, 1+salto)
            return memoria[entrada[salto], salto]
    return 0


print(saltos("101011101001100101111001",0))


